/* 
配置TFT_eSPI库文件的User_Setup.h文件：
SPI引脚连接：
#define TFT_MOSI 23
#define TFT_SCLK 18
#define TFT_CS   -1  
#define TFT_DC   17  
#define TFT_RST   5

ST7735 0.96 160*80 :
#define ST7735_DRIVER
#define ST7735_REDTAB160x80
*/

#ifndef show_H
#define show_H
#include <Arduino.h>
#include <TFT_eSPI.h>
#include <SPI.h>

TFT_eSPI tft = TFT_eSPI();        //定义彩屏对象

//16*16字模 逐行式 顺向高位在前 C51 阴码
static const unsigned char PROGMEM dian[] = {
0x01,0x00,0x01,0x00,0x01,0x00,0x3F,0xF8,0x21,0x08,0x21,0x08,0x21,0x08,0x3F,0xF8,
0x21,0x08,0x21,0x08,0x21,0x08,0x3F,0xF8,0x21,0x0A,0x01,0x02,0x01,0x02,0x00,0xFE};/*电*/
static const unsigned char PROGMEM ya[]   = {
0x00,0x00,0x3F,0xFE,0x20,0x00,0x20,0x80,0x20,0x80,0x20,0x80,0x20,0x80,0x2F,0xFC,
0x20,0x80,0x20,0x80,0x20,0x90,0x20,0x88,0x20,0x88,0x40,0x80,0x5F,0xFE,0x80,0x00};/*压*/
static const unsigned char PROGMEM liu[]  = {
0x00,0x80,0x20,0x40,0x17,0xFE,0x10,0x80,0x81,0x10,0x42,0x08,0x47,0xFC,0x10,0x04,
0x10,0x00,0x22,0x48,0xE2,0x48,0x22,0x48,0x22,0x48,0x22,0x4A,0x24,0x4A,0x08,0x46};/*流*/
static const unsigned char PROGMEM jiao[] = {
0x10,0x40,0x10,0x20,0x10,0x20,0x11,0xFE,0xFC,0x00,0x10,0x88,0x31,0x04,0x3A,0x02,
0x54,0x88,0x50,0x88,0x90,0x50,0x10,0x50,0x10,0x20,0x10,0x50,0x10,0x88,0x13,0x06};/*校*/
static const unsigned char PROGMEM zhun[] = {
0x01,0x40,0x41,0x20,0x21,0x20,0x23,0xFE,0x02,0x20,0x16,0x20,0x1B,0xFC,0x12,0x20,
0x22,0x20,0x23,0xFC,0xE2,0x20,0x22,0x20,0x22,0x20,0x23,0xFE,0x22,0x00,0x02,0x00};/*准*/


//TFT屏幕初始化
void TFTcsh(int xy){
  tft.init();                       //初始化对象
  tft.fillScreen(0x0000);           //填充背景颜色
  if(xy == 0){
    tft.setRotation(1);             //旋转屏幕0,1,2,3 : 0°,90°,180°,270°
  }else{
    tft.setRotation(3);              
  }
}

//显示模式0
void TFT0(float vou, float aou, float wou, float vsd, float asd, float wsd, float vin, float c, float xy){
  int x1 = 2;
  int x2 = 75;
  int x3 = 100;
  int x4 = -1;
  int vo = 3;
  int vs = 3; 
  int wo = 3; 
  int ws = 3;
  if(vou >= 10.0 ){ vo = 2; }
  if(vsd >= 10.0 ){ vs = 2; }
  if(wou >= 100.0){ wo = 1; }else if(wou >= 10.0 ){ wo = 2; }
  if(wsd >= 100.0){ ws = 1; }else if(wsd >= 10.0 ){ ws = 2; }
  if(int(xy) == 0){       
  }else if(int(xy) == 1){ x4 = 17; 
  }else if(int(xy) == 2){ x4 = 37; 
  }else if(int(xy) == 3){ x4 = 57; 
  }
  tft.fillScreen(0x0000);   
  tft.setTextSize(2);
  tft.drawFastHLine(x3, x4, 60, 0x07FF );  //划线
 
  tft.setTextColor(0xF800);       
  tft.setCursor(x1, 0);   tft.print(vou, vo);
  tft.setCursor(x2, 0);   tft.print("V");
  tft.setCursor(x3, 0);   tft.print(vsd, vs);
   
  tft.setTextColor(0x07E0);
  tft.setCursor(x1, 21);  tft.print(aou, 3);
  tft.setCursor(x2, 21);  tft.print("A");
  tft.setCursor(x3, 21);  tft.print(asd, 3);
  
  tft.setTextColor(0xFFE0);  
  tft.setCursor(x1, 41);  tft.print(wou, wo);
  tft.setCursor(x2, 41);  tft.print("W");
  tft.setCursor(x3, 41);  tft.print(wsd, ws);
  
  tft.setTextColor(0x001F); 
  tft.setCursor(x1, 64);  tft.print(vin, 2);
  tft.setCursor(69, 64);  tft.print("VC"); 
  tft.setCursor(x3, 64);  tft.print(c,   2);

}

//显示模式1
void TFT1(float vou, float aou, float wou, float vsd, float asd, float wsd, float xy){
  int x1 = 2;
  int x2 = 140;
  int x4 = -1;
  if(int(xy) == 0){       
  }else if(int(xy) == 1){ x4 = 24; 
  }else if(int(xy) == 2){ x4 = 50; 
  }else if(int(xy) == 3){ x4 = 78; 
  }
  tft.fillScreen(0x0000);   
  tft.setTextSize(3); 
  tft.drawFastHLine(x1, x4, 160, 0x07FF );  
               
  tft.setTextColor(0xF800);       
  tft.setCursor(x1, 1);   
  if(int(xy) == 1){ tft.print(vsd, 3); }else{ tft.print(vou, 3); }
  tft.setCursor(x2, 1);   tft.print("V");
  
  tft.setTextColor(0x07E0);
  tft.setCursor(x1, 28);  
  if(int(xy) == 2){ tft.print(asd, 3); }else{ tft.print(aou, 3); }
  tft.setCursor(x2, 28);  tft.print("A");
  
  tft.setTextColor(0xFFE0); 
  tft.setCursor(x1, 55);  
  if(int(xy) == 3){ tft.print(wsd, 3); }else{ tft.print(wou, 3); }
  tft.setCursor(x2, 55);  tft.print("W");
}

//显示模式2
void TFT2(float vou, float aou, float vx, float ax, float rv, float ra, float xy){
  int x1 = 2;
  int x2 = 75;
  int c1 = 0x780F;
  int c2 = 0x780F;
  int c3 = 0x780F;
  int c4 = 0x780F;
  if(int(xy) == 0){       c1 = 0x07FF;     
  }else if(int(xy) == 1){ c2 = 0x07FF; 
  }else if(int(xy) == 2){ c3 = 0x07FF;
  }else if(int(xy) == 3){ c4 = 0x07FF;
  }    
  
  tft.fillScreen(0x0000);   
  tft.setTextSize(2);
 
  tft.setTextColor(0xF800);        
  tft.setCursor(x1, 0);   tft.print(vou, 3);
  tft.setCursor(x2, 0);   tft.print("V");
  tft.setCursor(96, 0);   tft.print( rv, 3);
   
  tft.setTextColor(c1);
  tft.setCursor(x1, 22);  tft.print( vx, 3);
  tft.setCursor(x2, 22);  tft.print("V");
  
  //绘制(X坐标 Y坐标 字模数据 字体宽度 字体高度 颜色）
  tft.drawBitmap( 96, 22, dian, 16, 16, c2); 
  tft.drawBitmap(112, 22,   ya, 16, 16, c2);
  tft.drawBitmap(128, 22, jiao, 16, 16, c2);
  tft.drawBitmap(144, 22, zhun, 16, 16, c2);
  
  tft.setTextColor(0x07E0);  
  tft.setCursor(x1, 42);  tft.print(aou, 3);
  tft.setCursor(x2, 42);  tft.print("A");
  tft.setCursor(96, 42);  tft.print( ra, 2);
  
  tft.setTextColor(c3);
  tft.setCursor(x1, 64);  tft.print( ax, 3);
  tft.setCursor(x2, 64);  tft.print("A"); 
  
  tft.drawBitmap( 96, 62, dian, 16, 16, c4); 
  tft.drawBitmap(112, 62,  liu, 16, 16, c4);
  tft.drawBitmap(128, 62, jiao, 16, 16, c4);
  tft.drawBitmap(144, 62, zhun, 16, 16, c4);
}



#endif
